from PyQt5 import QtWidgets, uic
import sys
import VertalerErik
from PyQt5.QtWidgets import (QMainWindow, QTextEdit,
    QAction, QFileDialog, QApplication)
from PyQt5.QtGui import QIcon

'''   Copyright [2019] [Ir. Erik Mols / epmols@gmail.com]

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.'''
class Ui(QtWidgets.QDialog):
    def __init__(self):
        super().__init__()
        uic.loadUi('LatijnTransGui.ui', self)
        self.bOpen = self.findChild(QtWidgets.QPushButton, 'pushButton')
        self.bSave = self.findChild(QtWidgets.QPushButton, 'pushButton_2')
        self.bVertaal = self.findChild(QtWidgets.QPushButton, 'pushButton_3')
        self.sLabel = self.findChild(QtWidgets.QLabel, 'label' )
        self.bOpen.clicked.connect(self.open)
        self.bSave .clicked.connect(self.save)
        self.bVertaal.clicked.connect(self.vertaal)
        self.vertaler = None
        self.bestand = None #dict
        self.waarde = None
        self.resultaat = None


        self.show()


    def open(self):
       fname = QFileDialog.getOpenFileName(self, 'Open file', '/home')
       self.bestand = fname[0]
       print(fname)
       print(type(self.bestand))
       self.sLabel.setText(str(fname))
       try:
           self.vertaler = VertalerErik.Vertaler('final.txt', self.bestand)
           self.vertaler.vertaalDict()

       except:
           self.sLabel.setText("Foutmelding Kan niet vertalen")

    def save(self):

       fname = QFileDialog.getSaveFileName(self, 'Save file', '/home')

       if fname[0]:
           self.resultaat = open(fname[0], 'w+')
           self.sLabel.setText("Opslag bestand geselecteerd")


    def vertaal(self):
        self.sLabel.setText("Start Vertaling .... Dit kan even duren")
        self.waarde = self.vertaler.getVertaling()
        self.resultaat.write(self.waarde)  # Hier iets mee doen!
        self.resultaat.close()
        self.sLabel.setText("Vertaling is klaar")

app = QtWidgets.QApplication(sys.argv)
window = Ui()
app.exec_()
