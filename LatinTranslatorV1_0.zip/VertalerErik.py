from ast import literal_eval
import re
'''   Copyright [2019] [Ir. Erik Mols / epmols@gmail.com]

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.'''
class Vertaler:
    def __init__(self, dict, bestand):
        f = open(dict, "r", encoding="utf8")
        dd = f.read().lower()
        #for letter in f.readlines():
        #    dd += letter

        self.dict = literal_eval(dd)
        self.keyList = sorted(self.dict.keys(), key=len, reverse=True)
        f.close()
        f = open(bestand, "r")
        temp = f.read()
        temp.lower()
        self.bestand = temp
        f.close()
        self.vertaald = False
        self.count = 0
        self.countVal = 0


    def vertaal(self):
        translated = ""
        for woord in self.bestand.split():
            try:
                waarde = self.dict[woord]
                translated += woord + "[" + waarde + "]"
            except:
                translated += woord + " "
        return translated

    def vertaalDict(self):
        for wg in self.keyList:
            self.count += 1
            temp = self.dict[wg]
            t2 = wg.upper() + " [" + temp.upper() + "] "
            self.bestand = re.sub(wg, t2, self.bestand)
        for c in self.bestand:
            if c == "[":
                self.countVal += 1

        self.vertaald = True
        self.bestand = self.bestand.lower()
        self.bestand += "\nGrootte Dictionary: " + str(self.count) + "\n"
        self.bestand += "Aantal Vertalingen: " + str(self.countVal)

    def getVertaling(self):
        if(self.vertaald):
            return self.bestand
        else:
            return "Er is nog geen vertaling beschikbaar"


#ding = Vertaler("final.txt", "text.txt")
#ding.vertaalDict()
#waarde = ding.getVertaling()
#print(waarde)
